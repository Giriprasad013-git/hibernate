package org.alvas.hibernate_simple_project;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class UserUpdateController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("giri");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id to update");
		int us = sc.nextInt();
		System.out.println("Enter the new name");
		String nm = sc.next();
		System.out.println("Enter the new name");
		String mail = sc.next();

		User user = em.find(User.class, us);
		user.setName(nm);
		user.setEmail(mail);
		et.begin(); 
		em.merge(user);// for update merge method
		et.commit();
		System.out.println("......Data Updated......");
	}

}
