package org.alvas.hibernate_simple_project;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class UserGetByNameController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("giri");
		EntityManager em = emf.createEntityManager();
		String quary = "SELECT u FROM User u where u.name = ?1";
		
		Query quary2 = em.createQuery(quary);
		quary2.setParameter(1, "Giri");
		List<User> list = quary2.getResultList();
		list.forEach(a->System.out.println(a.getId()+"\n"+a.getName()+"\n"+a.getEmail()+"\n"));
	}

}
