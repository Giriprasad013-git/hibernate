package org.alvas.hibernate_simple_project;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class findById {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("giri");
		EntityManager em = emf.createEntityManager();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id to display");
		int us = sc.nextInt();
		User user = em.find(User.class, us);
		System.out.println("User Id    : " + user.getId());
		System.out.println("User Name  : " + user.getName());
		System.out.println("User Email : " + user.getEmail());
	}

}
