package org.alvas.hibernate_simple_project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class UserInsertController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("giri");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		User user = new User();

		user.setName("Giri");
		user.setId(5);
		user.setEmail("giri@gmail.com");

		et.begin();
		em.persist(user);
		et.commit();
		System.out.println("......Data Stored......");
	}
}
