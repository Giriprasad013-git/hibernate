package org.alvas.hibernate_simple_project;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class UserDeleteController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("giri");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id to delete");
		int us = sc.nextInt();
		User user = em.find(User.class, us);
		et.begin();
		em.remove(user);
		et.commit();
		System.out.println("Data Deleted");
	}

}
