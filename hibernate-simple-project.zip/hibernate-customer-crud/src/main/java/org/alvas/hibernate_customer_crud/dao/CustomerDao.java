package org.alvas.hibernate_customer_crud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.alvas.hibernate_customer_crud.dto.Customer;

public class CustomerDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("giri");
	EntityManager em;
	EntityTransaction et;

	public Customer insertCustomer(Customer customer) {
		em = emf.createEntityManager();
		et = em.getTransaction();
		if (customer != null) {
			et.begin();
			em.persist(customer);
			et.commit();
			System.out.println("........DataStored.........");
		} else {
			System.out.println("...please set the data in customer...");
		}

		return customer;

	}

	public Customer updateCustomer(int id, String name) {
		em = emf.createEntityManager();
		et = em.getTransaction();
		Customer customer2 = em.find(Customer.class, id);
		customer2.setName(name);
		if (customer2 != null) {
			et.begin();
			em.merge(customer2);
			et.commit();
			System.out.println("........DataUpdated.........");
		} else {
			System.out.println("...please set the data in customer...");
		}

		return customer2;
	}

	public Customer deleteCustomer(int id) {
		em = emf.createEntityManager();
		et = em.getTransaction();
		Customer customer = em.find(Customer.class, id);
		if (customer != null) {
			et.begin();
			em.remove(customer);
			et.commit();
			System.out.println("........DataDeleted.........");
		} else {
			System.out.println("...please set the data in customer...");
		}

		return customer;

	}

	public void getAllData() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("giri");
		EntityManager em = emf.createEntityManager();
		String query = "SELECT u FROM Customer u";
		Query query2 = em.createQuery(query);
		List<Customer> list = query2.getResultList();
		list.forEach(a -> System.out.println(a.getId() + "\n" + a.getName() + "\n" + a.getEmail() + "\n"));

	}

}
