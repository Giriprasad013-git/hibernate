package Controller;

import java.util.Arrays;
import java.util.List;

import many_to_many.dao.StudentDao;
import many_to_many.dto.Student;
import many_to_many.dto.Subjects;

public class StudentSaveController {
	public static void main(String[] args) {
		Subjects subjects1 =new Subjects();
		Subjects subjects2 =new Subjects();
		Student student1 = new Student();
		Student student2 = new Student();
		StudentDao dao = new StudentDao();

		subjects1.setSubjectName("Computer-O");
		subjects1.setSubjectAuthor("James-grill");
		
		subjects2.setSubjectName("C-language");
		subjects2.setSubjectAuthor("Danies-Ritchi");
		
		List<Subjects> subjects = Arrays.asList(subjects1,subjects2);
		
		student1.setStudentName("Giri");
		student1.setStudentPhone(122211);
		student1.setSubjects(subjects);
		
		student2.setStudentName("appi");
		student2.setStudentPhone(2978738);
		student2.setSubjects(subjects);
		
		dao.saveStudent(student1, student2, subjects);
	}
}
