package org.alvas.hibernate_customer_crud.controller;

import java.util.Scanner;

import org.alvas.hibernate_customer_crud.dao.CustomerDao;
import org.alvas.hibernate_customer_crud.dto.Customer;

public class CustomerController {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Customer customer;
		CustomerDao customerDao = new CustomerDao();
		while (true) {
			System.out.println("1.insertCustomer\n2.updateCustomer\n3.updatecustomer\n4.getAllData\n");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1: {
				customer = new Customer();

				System.out.println("Enter the customerName");
				customer.setName(sc.next());
				System.out.println("Enter the customerEmail");
				customer.setEmail(sc.next());
				customerDao.insertCustomer(customer);
				break;
			}
			case 2: {

				System.out.println("Enter the customerId");
				int id = sc.nextInt();
				System.out.println("Enter the customerName");
				String name = sc.next();
//				System.out.println("Enter the customerEmail");
//				customer.setEmail(sc.next());
				Customer customer1 = customerDao.updateCustomer(id, name);
				System.out.println(customer1.getId() + " " + customer1.getName());
				break;
			}
			case 3: {
				customer = new Customer();
				System.out.println("Enter the customerId");
				int id = sc.nextInt();
				customerDao.deleteCustomer(id);
				break;
			}
			case 4: {
				customerDao.getAllData();
				break;
			}
			}
		}
	}
}
