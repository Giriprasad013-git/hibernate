package one_to_one_bi.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import one_to_one_bi.dto.Pan;
import one_to_one_bi.dto.Person;

public class PersonDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("giri");
	EntityManager em;
	EntityTransaction et;

	public Person savePerson(Person person, Pan pan) {
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		em.persist(pan);
		em.persist(person);
		et.commit();

		return person;

	}
}
