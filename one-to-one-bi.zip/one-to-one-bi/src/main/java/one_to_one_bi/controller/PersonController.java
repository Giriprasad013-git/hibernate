package one_to_one_bi.controller;

import one_to_one_bi.dao.PersonDao;
import one_to_one_bi.dto.Pan;
import one_to_one_bi.dto.Person;

public class PersonController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonDao dao =new  PersonDao();
		Person person = new Person();
		Pan pan = new Pan();
		
		pan.setPanNumber("DKFHGS0023");
		pan.setPanAddress("Belagavi");
		
		person.setPersonName("GIRI");
		person.setPersonEmail("GIRI@gmail.com");
		pan.setPerson(person);
		
		dao.savePerson(person, pan);
	}

}
