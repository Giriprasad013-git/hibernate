package org.alvas.spring_core_xml;

public class Person {
	public void getStudent() {
		System.out.println("Person");
	}
}
