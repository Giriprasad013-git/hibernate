package org.alvas.spring_core_xml.setter.injection;

import org.alvas.pring_core_xml_user.User;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class teachertest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConfigurableApplicationContext applicationContext = new ClassPathXmlApplicationContext("setter-injection.xml");
		Teacher teacher= (Teacher) applicationContext.getBean("myTeacher");
		
		System.out.println(teacher.id);
		System.out.println(teacher.name);
		System.out.println(teacher.sub);
	}

}
