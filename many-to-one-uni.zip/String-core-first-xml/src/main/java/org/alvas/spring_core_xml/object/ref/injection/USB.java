package org.alvas.spring_core_xml.object.ref.injection;

public class USB {
	public void getUsb() {
		System.out.println("USB");
	}
}
