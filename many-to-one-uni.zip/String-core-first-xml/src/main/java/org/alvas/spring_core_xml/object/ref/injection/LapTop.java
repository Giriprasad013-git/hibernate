package org.alvas.spring_core_xml.object.ref.injection;

public class LapTop {
	USB usb;

	public USB getUsb() {
		return usb;
	}

	public void setUsb(USB usb) {
		this.usb = usb;
	}
	
	public void getLaptop() {
		System.out.println("in my laptop");
		usb.getUsb();
	}
	
}
