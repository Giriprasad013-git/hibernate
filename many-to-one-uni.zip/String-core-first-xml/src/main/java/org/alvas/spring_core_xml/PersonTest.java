package org.alvas.spring_core_xml;

public class PersonTest {

}
