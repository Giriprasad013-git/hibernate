package org.alvas.spring_core_xml;

public class Student {
	public void getStudent() {
		System.out.println("Students");
	}
}
