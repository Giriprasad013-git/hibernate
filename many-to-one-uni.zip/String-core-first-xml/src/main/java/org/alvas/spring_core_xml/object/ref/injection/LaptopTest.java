package org.alvas.spring_core_xml.object.ref.injection;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LaptopTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConfigurableApplicationContext applicationContext= new ClassPathXmlApplicationContext("obj-ref-setter-injection.xml");
		LapTop laptop = (LapTop) applicationContext.getBean("myLaptop");
		laptop.getLaptop();
	}

}
