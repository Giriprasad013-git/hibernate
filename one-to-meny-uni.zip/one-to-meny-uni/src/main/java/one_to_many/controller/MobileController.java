package one_to_many.controller;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import one_to_many_uni.dao.MobileDao;
import one_to_many_uni.dto.Mobile;
import one_to_many_uni.dto.Sim;

public class MobileController {

	public static void main(String[] args) {
		Mobile mobile = new Mobile();

		Sim sim1 = new Sim();
		Sim sim2 = new Sim();

//		List<Sim> sim = Arrays.asList(sim1,sim2);

		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("1.Insert\n");
			System.out.println("Enter your choice");
			int ch = sc.nextInt();
			MobileDao dao = new MobileDao();

			switch (ch) {
			case 1: {
				String sname = sc.next();
				String provider = sc.next();
				String sname2 = sc.next();
				String provider2 = sc.next();
				String mname = sc.next();
				String model = sc.next();
				sim1.setName(sname);
				sim1.setProvider(provider);
				sim2.setName(sname2);
				sim2.setProvider(provider2);
				List<Sim> sims = Arrays.asList(sim1, sim2);
				mobile.setName(mname);
				mobile.setModel(model);
				mobile.setList(sims);
				dao.insert(mobile, sim1, sim2);

			}
				break;

			case 2: {
				int id = 1;
				String simname = "Tata-Docomo";
				String moblename = "Sony";
				dao.updateMobileById(id, simname, moblename);
			}

			default:
				System.out.println("Check your input");
				break;
			}
		}
	}

}
