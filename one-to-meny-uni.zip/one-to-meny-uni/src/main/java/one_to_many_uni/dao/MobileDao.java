package one_to_many_uni.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import one_to_many_uni.dto.Mobile;
import one_to_many_uni.dto.Sim;

public class MobileDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("vikas");
	EntityManager em;
	EntityTransaction et;

	public Mobile insert(Mobile mobile, Sim sim1, Sim sim2) {
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		em.persist(mobile);
		em.persist(sim1);
		em.persist(sim2);
		et.commit();
		return mobile;
	}

	public Mobile updateMobileById(int id, String simname, String mobilename) {
		em = emf.createEntityManager();
		et = em.getTransaction();

		Mobile mobile1 = em.find(Mobile.class, id);
		et.begin();
		mobile1.setName(mobilename);

		List<Sim> list = mobile1.getList();
		for (Sim sim : list) {
			if (sim.getName().equals("JIO")) {
				sim.setName(simname);
				em.merge(sim);
			}
		}
		em.merge(mobile1);
		et.commit();
		mobile1.setName(mobilename);
		mobile1.setList(list);
		return mobile1;
	}
}
