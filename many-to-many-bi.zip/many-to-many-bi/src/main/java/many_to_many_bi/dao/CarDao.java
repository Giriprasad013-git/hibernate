package many_to_many_bi.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import many_to_many_bi.dto.Car;
import many_to_many_bi.dto.Feature;

public class CarDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("giri");
	EntityManager em;
	EntityTransaction et;

	public List<Car> saveCar(List<Car> cars, List<Feature> fetures) {
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		for (Feature feture : fetures) {
			em.persist(feture);
		}
		for (Car car : cars) {
			em.persist(car);
		}
		et.commit();
		return cars;
	}

}
