package many_to_many_bi.controller;

import java.util.Arrays;
import java.util.List;

import many_to_many_bi.dao.CarDao;
import many_to_many_bi.dto.Car;
import many_to_many_bi.dto.Feature;

public class CarController {
	public static void main(String[] args) {
		CarDao carDao = new CarDao();
		Car car1 = new Car();
		Car car2 = new Car();
		Feature feature1 = new Feature();
		Feature feature2 = new Feature();

		car1.setCarName("TESLA");
		car1.setCarPrice(1111110);

		car2.setCarName("KIA");
		car2.setCarPrice(1000000);

		List<Car> cars = Arrays.asList(car1, car2);

		feature1.setFeatureName("Autometic-drive");
		feature2.setFeatureName("Wifi");

		List<Feature> features = Arrays.asList(feature1, feature2);

		car1.setFeatures(features);
		car2.setFeatures(features);

		feature1.setCars(cars);
		feature2.setCars(cars);

		carDao.saveCar(cars, features);
	}
}
