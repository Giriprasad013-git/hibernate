package Controller;

import many_to_many.dao.StudentDao;
import many_to_many.dto.Student;
import many_to_many.dto.Subjects;

public class StudentUpdateController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Subjects subjects =new Subjects();
		Student student1 = new Student();
		StudentDao dao = new StudentDao();
		dao.UpdateStudent(student1,1);
	}

}
