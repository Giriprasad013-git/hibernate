package many_to_many.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity

public class Subjects {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int SubjectsId;
	private String SubjectName;
	private String SubjectAuthor;

	public int getSubjectsId() {
		return SubjectsId;
	}

	public void setSubjectsId(int subjectsId) {
		SubjectsId = subjectsId;
	}

	public String getSubjectName() {
		return SubjectName;
	}

	public void setSubjectName(String subjectName) {
		SubjectName = subjectName;
	}

	public String getSubjectAuthor() {
		return SubjectAuthor;
	}

	public void setSubjectAuthor(String subjectAuthor) {
		SubjectAuthor = subjectAuthor;
	}

}
