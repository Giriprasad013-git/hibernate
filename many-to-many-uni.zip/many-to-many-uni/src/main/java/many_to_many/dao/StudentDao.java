package many_to_many.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import many_to_many.dto.Student;
import many_to_many.dto.Subjects;

public class StudentDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("giri");
	EntityManager em;
	EntityTransaction et;
	public Student saveStudent(Student student1,Student student2,List<Subjects> list) {
		em=emf.createEntityManager();
		et=em.getTransaction();
		et.begin();
		em.persist(student1);
		em.persist(student2);
		for (Subjects subjects : list) {
			em.persist(subjects);
		}
		et.commit();
		return student1;
	}
	public Student UpdateStudent(Student student1,int id) {
		em=emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		em.find(Student.class, 1);
		em.merge(student1);
		et.commit();
		return student1;
	}
}
